
Scripts

Bootstrap_CI_Helper_Functions.R
	Defines some functions for computing mediation effects from regression coefficients.
	
Run_Bootstrap_Functions.R
	Defines functions which perform bootstrap sampling, fitting GLMMs and extracting coefficients.
	Separate sections for parametric and non-parametric.
	
Analyse_Bootstrap_Functions.R
	Defines functions for constructing confidence intervals based on parameter estimates computed from the bootstrap samples.

Run_Both_Bootstraps.R
	Runs the analysis and makes some plots. All of the actual analysis occurs in the script. The other files just define functions that we use here.
	





Data Files

CleanDataFile-Trust-Nov102023.RData
	Contents: dat.ma
	A processed version of the original dataset. Processing consists of removing irrelevant variables, combining some levels of the retained variables, and removing missing values.
	
Fitted_Models.RData
	Contents: mod_Y, mod_M
	lme4 models fit to the cleaned dataset. Fitting occurs in Run_Both_Bootstraps.R

Estimated_Effects.RData
	Contents: all_effects_data, all_med_effects_data
	Regression coefficients and mediation effects estimated directly from the cleaned dataset. Computed and saved in Run_Both_Bootstraps.R
	
Both_Boots_Real_Data.RData
	Contents: boot_results_par, boot_results_npar
	Output from running our bootstrap analysis (i.e. all_boot_reps_par/all_boot_reps_npar from Run_Bootstrap_Functions.R) with B=300 replicates. Computed and saved in Run_Both_Bootstraps.R
	